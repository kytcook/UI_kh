const btn_add = document.querySelector(".btn_add")
const items = document.querySelector(".items")


btn_add.addEventListener('click', (e) =>{
  console.log("add버튼 클릭");;
  
})